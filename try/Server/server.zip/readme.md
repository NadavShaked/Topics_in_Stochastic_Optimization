Super Market Server

for running the server navigate to the main folder, open the terminal.
for build the server:
1.  npm init -y
2.  npm install express

for run the server:
1.  npmnode . <?* args>     (args are possible)